WORLD WAR CUP v4
=================

HTML + CSS + JavaScript puro. Não requer bibliotecas externas.

Base atualizada:
- 30 países
- modo solo sem encerramento automático
- 2 a 6 players humanos em pass-and-play
- 4 reservas iniciais
- auto-substituição
- 4-3-3, 4-4-2 e 3-5-3 obrigatórias
- tática personalizada com 11 titulares e 1 goleiro
- OVR determinístico baseado na referência EA SPORTS FC 27 onde verificado; lendas continuam especiais
- chance de gol por posição e OVR
- goleiro sem gol quase nunca e sem goleiro gera grande penalidade defensiva
- prorrogação + pênaltis
- dinheiro por conquista e por gol
- preços de mercado mais altos
- mercado com 20 famosos
- mercado vivo de jogadores 87+ não capturados
- venda com confirmação
- save/load em localStorage
- artilharia
- eventos bons/ruins e evento lendário separado com chance de 0,5% e máximo de 1 por campanha
- ícone/lenda recebido é removido do mercado
- Espanha visualmente afastada
- mapa com zoom, pan, arrastar e pinça
- maiores áreas clicáveis no mobile
- sem animação de hover
- trade entre players com jogadores, territórios e milhões inteiros
- quando a batalha começa, o X fica bloqueado e não pode cancelar

Observação de ratings:
A base tenta seguir as ratings do EA SPORTS FC 27. A EA publicou uma base de ratings de mais de 21.000 jogadores. Como a base completa passa por atualizações e alguns jogadores/seleções podem mudar, os valores não verificados individualmente foram mantidos em uma faixa determinística e balanceada. As lendas usam ratings especiais do jogo.
